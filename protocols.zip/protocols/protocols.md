# Reporter competent cells

Use this page to compose the protocol interactively. Fill inputs, choose Quick or Full, then Generate.

<div id="controls" style="display:grid;gap:0.5rem;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end;margin:1rem 0;">
  <label>Strain
    <input id="strain" type="text" value="Mach1" />
  </label>
  <label>Plasmid
    <input id="plasmid" type="text" value="pGhost12-A" />
  </label>
  <label>Scale (mL)
    <input id="scale_mL" type="number" min="10" step="10" value="100" />
  </label>
  <label>View
    <select id="view">
      <option value="quick">Quick</option>
      <option value="full">Full</option>
    </select>
  </label>
  <div>
    <button id="run">Generate</button>
    <button id="clear" type="button">Clear</button>
  </div>
</div>

<noscript><p><strong>Note:</strong> This page requires JavaScript to assemble protocols.</p></noscript>

<hr/>

<div id="protocol-output"></div>

<script src="../runtime/render.js"></script>
<script src="../runtime/inventory.js"></script>
<script src="../runtime/runtime.js"></script>
<script src="../modules/reporter_comp_cells.js"></script>

<script>
  // Helpers
  function getEl(id){ return document.getElementById(id); }
  function setDisabled(el, on){ el.disabled = !!on; }
  function readInputs(){
    return {
      strain: getEl("strain").value.trim() || "Mach1",
      plasmid: getEl("plasmid").value.trim() || "pGhost12-A",
      scale_mL: parseInt(getEl("scale_mL").value, 10) || 100,
      view: getEl("view").value,
    };
  }
  function writeToURL(params){
    const url = new URL(location.href);
    Object.entries(params).forEach(([k,v]) => url.searchParams.set(k, v));
    history.replaceState(null, "", url);
  }
  function readFromURL(){
    const url = new URL(location.href);
    const qs = (k, d) => url.searchParams.get(k) || d;
    getEl("strain").value = qs("strain", getEl("strain").value);
    getEl("plasmid").value = qs("plasmid", getEl("plasmid").value);
    getEl("scale_mL").value = qs("scale_mL", getEl("scale_mL").value);
    getEl("view").value = qs("view", getEl("view").value);
  }

  // Init
  ProtocolRender.init("#protocol-output");
  readFromURL();

  // Events
  getEl("run").addEventListener("click", async () => {
    const btn = getEl("run");
    setDisabled(btn, true);
    getEl("protocol-output").innerHTML = "";
    const inputs = readInputs();
    writeToURL(inputs);
    try {
      await runWorkflow({ root: "reporter_comp_cells", inputs });
    } catch (err) {
      const pre = document.createElement("pre");
      pre.textContent = (err && err.message) ? err.message : String(err);
      getEl("protocol-output").appendChild(pre);
    } finally {
      setDisabled(btn, false);
    }
  });

  getEl("clear").addEventListener("click", () => {
    getEl("protocol-output").innerHTML = "";
  });
</script>
