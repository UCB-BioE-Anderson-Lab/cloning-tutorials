# Start Dilution for Competent Cell Prep

## Quick
- 100 mL 2YT + antibiotic in **250–500 mL** flask  
- Inoculate **2.5 mL** (1:40)  
- Shake **4–5 h** at **37 °C**

## Full
1. Prepare 100 mL 2YT with the correct antibiotic.  
2. Use a 250–500 mL baffled flask for aeration; confirm sterility.  
3. Inoculate 2.5 mL overnight into 100 mL (1:40). Record start time.  
4. Place on shaker; apply room-specific notes if using an alternate shaker.  
5. Grow 4–5 h to log phase. Optionally verify OD.
