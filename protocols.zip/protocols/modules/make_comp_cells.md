# Make Competent Cells

## Quick
- Chill culture, pellet, resuspend with cold buffer  
- Repeat washes; aliquot; snap-freeze or use fresh

## Full
1. Chill culture on ice.  
2. Centrifuge cold; discard supernatant.  
3. Resuspend in ice-cold buffer; repeat per SOP.  
4. Final resuspension, aliquot on ice, snap-freeze or proceed immediately.
