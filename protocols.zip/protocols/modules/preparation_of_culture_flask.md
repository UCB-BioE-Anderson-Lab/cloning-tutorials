# Preparation of Culture Flask

## Quick
- Wrap mouth with foil or use sterile filter cap
- Autoclave; label date

## Full
1. Inspect flask for chips/cracks; discard if damaged.  
2. Wrap opening with aluminum foil or fit a sterile filter cap.  
3. Autoclave on appropriate cycle.  
4. Cool/dry, store near sterile bench for use.
